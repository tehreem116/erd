import React from "react";
import "./Contact.css";
import { Github,Linkedin,Mail   } from 'lucide-react';


function Contact() {
  return (
    <footer id="Contact" className="footer">
      <div className="footer-content">
        <h2>📞 Contact Me</h2>
        <p>Email: <a href="mailto:F2023266946@umt.edu.pk">F2023266946@umt.edu.pk</a></p>
        <p>Phone: +92 370 6881985</p>
        <p>Location: Lahore, Pakistan</p>

        {/* Social Links */}
        <div className="social-icons">
          <a href="https://github.com/" target="_blank" rel="noreferrer">
            <Github />
          </a>
          <a href="https://www.linkedin.com/" target="_blank" rel="noreferrer">
            <Linkedin />
          </a>
          <a href="mailto:F2023266946@umt.edu.pk">
            <Mail  />
          </a>
        </div>

        <hr />
        <p className="footer-copy">© 2025 Thareem | All Rights Reserved</p>
      </div>
    </footer>
  );
}

export default Contact;
